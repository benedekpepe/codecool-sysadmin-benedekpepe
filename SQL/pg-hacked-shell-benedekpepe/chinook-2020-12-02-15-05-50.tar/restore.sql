--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.14 (Ubuntu 10.14-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.14 (Ubuntu 10.14-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.track DROP CONSTRAINT fk_trackmediatypeid;
ALTER TABLE ONLY public.track DROP CONSTRAINT fk_trackgenreid;
ALTER TABLE ONLY public.track DROP CONSTRAINT fk_trackalbumid;
ALTER TABLE ONLY public.playlisttrack DROP CONSTRAINT fk_playlisttracktrackid;
ALTER TABLE ONLY public.playlisttrack DROP CONSTRAINT fk_playlisttrackplaylistid;
ALTER TABLE ONLY public.invoiceline DROP CONSTRAINT fk_invoicelinetrackid;
ALTER TABLE ONLY public.invoiceline DROP CONSTRAINT fk_invoicelineinvoiceid;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT fk_invoicecustomerid;
ALTER TABLE ONLY public.employee DROP CONSTRAINT fk_employeereportsto;
ALTER TABLE ONLY public.customer DROP CONSTRAINT fk_customersupportrepid;
ALTER TABLE ONLY public.album DROP CONSTRAINT fk_albumartistid;
DROP INDEX public.ifk_trackmediatypeid;
DROP INDEX public.ifk_trackgenreid;
DROP INDEX public.ifk_trackalbumid;
DROP INDEX public.ifk_playlisttracktrackid;
DROP INDEX public.ifk_invoicelinetrackid;
DROP INDEX public.ifk_invoicelineinvoiceid;
DROP INDEX public.ifk_invoicecustomerid;
DROP INDEX public.ifk_employeereportsto;
DROP INDEX public.ifk_customersupportrepid;
DROP INDEX public.ifk_albumartistid;
ALTER TABLE ONLY public.track DROP CONSTRAINT pk_track;
ALTER TABLE ONLY public.playlisttrack DROP CONSTRAINT pk_playlisttrack;
ALTER TABLE ONLY public.playlist DROP CONSTRAINT pk_playlist;
ALTER TABLE ONLY public.mediatype DROP CONSTRAINT pk_mediatype;
ALTER TABLE ONLY public.invoiceline DROP CONSTRAINT pk_invoiceline;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT pk_invoice;
ALTER TABLE ONLY public.genre DROP CONSTRAINT pk_genre;
ALTER TABLE ONLY public.employee DROP CONSTRAINT pk_employee;
ALTER TABLE ONLY public.customer DROP CONSTRAINT pk_customer;
ALTER TABLE ONLY public.artist DROP CONSTRAINT pk_artist;
ALTER TABLE ONLY public.album DROP CONSTRAINT pk_album;
DROP TABLE public.track;
DROP TABLE public.playlisttrack;
DROP TABLE public.playlist;
DROP TABLE public.mediatype;
DROP TABLE public.invoiceline;
DROP TABLE public.invoice;
DROP TABLE public.genre;
DROP TABLE public.employee;
DROP TABLE public.customer;
DROP TABLE public.artist;
DROP TABLE public.album;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: album; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.album (
    albumid integer NOT NULL,
    title character varying(160) NOT NULL,
    artistid integer NOT NULL
);


ALTER TABLE public.album OWNER TO ubuntu;

--
-- Name: artist; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.artist (
    artistid integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.artist OWNER TO ubuntu;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.customer (
    customerid integer NOT NULL,
    firstname character varying(40) NOT NULL,
    lastname character varying(20) NOT NULL,
    company character varying(80),
    address character varying(70),
    city character varying(40),
    state character varying(40),
    country character varying(40),
    postalcode character varying(10),
    phone character varying(24),
    fax character varying(24),
    email character varying(60) NOT NULL,
    supportrepid integer
);


ALTER TABLE public.customer OWNER TO ubuntu;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.employee (
    employeeid integer NOT NULL,
    lastname character varying(20) NOT NULL,
    firstname character varying(20) NOT NULL,
    title character varying(30),
    reportsto integer,
    birthdate timestamp without time zone,
    hiredate timestamp without time zone,
    address character varying(70),
    city character varying(40),
    state character varying(40),
    country character varying(40),
    postalcode character varying(10),
    phone character varying(24),
    fax character varying(24),
    email character varying(60)
);


ALTER TABLE public.employee OWNER TO ubuntu;

--
-- Name: genre; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.genre (
    genreid integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.genre OWNER TO ubuntu;

--
-- Name: invoice; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.invoice (
    invoiceid integer NOT NULL,
    customerid integer NOT NULL,
    invoicedate timestamp without time zone NOT NULL,
    billingaddress character varying(70),
    billingcity character varying(40),
    billingstate character varying(40),
    billingcountry character varying(40),
    billingpostalcode character varying(10),
    total numeric(10,2) NOT NULL
);


ALTER TABLE public.invoice OWNER TO ubuntu;

--
-- Name: invoiceline; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.invoiceline (
    invoicelineid integer NOT NULL,
    invoiceid integer NOT NULL,
    trackid integer NOT NULL,
    unitprice numeric(10,2) NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.invoiceline OWNER TO ubuntu;

--
-- Name: mediatype; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.mediatype (
    mediatypeid integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.mediatype OWNER TO ubuntu;

--
-- Name: playlist; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.playlist (
    playlistid integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.playlist OWNER TO ubuntu;

--
-- Name: playlisttrack; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.playlisttrack (
    playlistid integer NOT NULL,
    trackid integer NOT NULL
);


ALTER TABLE public.playlisttrack OWNER TO ubuntu;

--
-- Name: track; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.track (
    trackid integer NOT NULL,
    name character varying(200) NOT NULL,
    albumid integer,
    mediatypeid integer NOT NULL,
    genreid integer,
    composer character varying(220),
    milliseconds integer NOT NULL,
    bytes integer,
    unitprice numeric(10,2) NOT NULL
);


ALTER TABLE public.track OWNER TO ubuntu;

--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.album (albumid, title, artistid) FROM stdin;
\.
COPY public.album (albumid, title, artistid) FROM '$$PATH$$/2986.dat';

--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.artist (artistid, name) FROM stdin;
\.
COPY public.artist (artistid, name) FROM '$$PATH$$/2987.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.customer (customerid, firstname, lastname, company, address, city, state, country, postalcode, phone, fax, email, supportrepid) FROM stdin;
\.
COPY public.customer (customerid, firstname, lastname, company, address, city, state, country, postalcode, phone, fax, email, supportrepid) FROM '$$PATH$$/2988.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.employee (employeeid, lastname, firstname, title, reportsto, birthdate, hiredate, address, city, state, country, postalcode, phone, fax, email) FROM stdin;
\.
COPY public.employee (employeeid, lastname, firstname, title, reportsto, birthdate, hiredate, address, city, state, country, postalcode, phone, fax, email) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.genre (genreid, name) FROM stdin;
\.
COPY public.genre (genreid, name) FROM '$$PATH$$/2990.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.invoice (invoiceid, customerid, invoicedate, billingaddress, billingcity, billingstate, billingcountry, billingpostalcode, total) FROM stdin;
\.
COPY public.invoice (invoiceid, customerid, invoicedate, billingaddress, billingcity, billingstate, billingcountry, billingpostalcode, total) FROM '$$PATH$$/2991.dat';

--
-- Data for Name: invoiceline; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.invoiceline (invoicelineid, invoiceid, trackid, unitprice, quantity) FROM stdin;
\.
COPY public.invoiceline (invoicelineid, invoiceid, trackid, unitprice, quantity) FROM '$$PATH$$/2992.dat';

--
-- Data for Name: mediatype; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.mediatype (mediatypeid, name) FROM stdin;
\.
COPY public.mediatype (mediatypeid, name) FROM '$$PATH$$/2993.dat';

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.playlist (playlistid, name) FROM stdin;
\.
COPY public.playlist (playlistid, name) FROM '$$PATH$$/2994.dat';

--
-- Data for Name: playlisttrack; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.playlisttrack (playlistid, trackid) FROM stdin;
\.
COPY public.playlisttrack (playlistid, trackid) FROM '$$PATH$$/2995.dat';

--
-- Data for Name: track; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.track (trackid, name, albumid, mediatypeid, genreid, composer, milliseconds, bytes, unitprice) FROM stdin;
\.
COPY public.track (trackid, name, albumid, mediatypeid, genreid, composer, milliseconds, bytes, unitprice) FROM '$$PATH$$/2996.dat';

--
-- Name: album pk_album; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT pk_album PRIMARY KEY (albumid);


--
-- Name: artist pk_artist; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT pk_artist PRIMARY KEY (artistid);


--
-- Name: customer pk_customer; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT pk_customer PRIMARY KEY (customerid);


--
-- Name: employee pk_employee; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT pk_employee PRIMARY KEY (employeeid);


--
-- Name: genre pk_genre; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.genre
    ADD CONSTRAINT pk_genre PRIMARY KEY (genreid);


--
-- Name: invoice pk_invoice; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT pk_invoice PRIMARY KEY (invoiceid);


--
-- Name: invoiceline pk_invoiceline; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.invoiceline
    ADD CONSTRAINT pk_invoiceline PRIMARY KEY (invoicelineid);


--
-- Name: mediatype pk_mediatype; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.mediatype
    ADD CONSTRAINT pk_mediatype PRIMARY KEY (mediatypeid);


--
-- Name: playlist pk_playlist; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT pk_playlist PRIMARY KEY (playlistid);


--
-- Name: playlisttrack pk_playlisttrack; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.playlisttrack
    ADD CONSTRAINT pk_playlisttrack PRIMARY KEY (playlistid, trackid);


--
-- Name: track pk_track; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT pk_track PRIMARY KEY (trackid);


--
-- Name: ifk_albumartistid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_albumartistid ON public.album USING btree (artistid);


--
-- Name: ifk_customersupportrepid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_customersupportrepid ON public.customer USING btree (supportrepid);


--
-- Name: ifk_employeereportsto; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_employeereportsto ON public.employee USING btree (reportsto);


--
-- Name: ifk_invoicecustomerid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_invoicecustomerid ON public.invoice USING btree (customerid);


--
-- Name: ifk_invoicelineinvoiceid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_invoicelineinvoiceid ON public.invoiceline USING btree (invoiceid);


--
-- Name: ifk_invoicelinetrackid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_invoicelinetrackid ON public.invoiceline USING btree (trackid);


--
-- Name: ifk_playlisttracktrackid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_playlisttracktrackid ON public.playlisttrack USING btree (trackid);


--
-- Name: ifk_trackalbumid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_trackalbumid ON public.track USING btree (albumid);


--
-- Name: ifk_trackgenreid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_trackgenreid ON public.track USING btree (genreid);


--
-- Name: ifk_trackmediatypeid; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX ifk_trackmediatypeid ON public.track USING btree (mediatypeid);


--
-- Name: album fk_albumartistid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT fk_albumartistid FOREIGN KEY (artistid) REFERENCES public.artist(artistid);


--
-- Name: customer fk_customersupportrepid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT fk_customersupportrepid FOREIGN KEY (supportrepid) REFERENCES public.employee(employeeid);


--
-- Name: employee fk_employeereportsto; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT fk_employeereportsto FOREIGN KEY (reportsto) REFERENCES public.employee(employeeid);


--
-- Name: invoice fk_invoicecustomerid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT fk_invoicecustomerid FOREIGN KEY (customerid) REFERENCES public.customer(customerid);


--
-- Name: invoiceline fk_invoicelineinvoiceid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.invoiceline
    ADD CONSTRAINT fk_invoicelineinvoiceid FOREIGN KEY (invoiceid) REFERENCES public.invoice(invoiceid);


--
-- Name: invoiceline fk_invoicelinetrackid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.invoiceline
    ADD CONSTRAINT fk_invoicelinetrackid FOREIGN KEY (trackid) REFERENCES public.track(trackid);


--
-- Name: playlisttrack fk_playlisttrackplaylistid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.playlisttrack
    ADD CONSTRAINT fk_playlisttrackplaylistid FOREIGN KEY (playlistid) REFERENCES public.playlist(playlistid);


--
-- Name: playlisttrack fk_playlisttracktrackid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.playlisttrack
    ADD CONSTRAINT fk_playlisttracktrackid FOREIGN KEY (trackid) REFERENCES public.track(trackid);


--
-- Name: track fk_trackalbumid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT fk_trackalbumid FOREIGN KEY (albumid) REFERENCES public.album(albumid);


--
-- Name: track fk_trackgenreid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT fk_trackgenreid FOREIGN KEY (genreid) REFERENCES public.genre(genreid);


--
-- Name: track fk_trackmediatypeid; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT fk_trackmediatypeid FOREIGN KEY (mediatypeid) REFERENCES public.mediatype(mediatypeid);


--
-- PostgreSQL database dump complete
--

